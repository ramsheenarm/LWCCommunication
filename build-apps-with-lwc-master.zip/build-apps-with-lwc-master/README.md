# Ursus Park sample app for Trailhead project [Build Flexible Apps with Lightning Web Components](https://trailhead.salesforce.com/content/learn/projects/lwc-build-flexible-apps)

We are not accepting contributions on this app.

Found an issue? Report it using the [Trailhead feedback form](https://trailhead.salesforce.com/help?support=home).
