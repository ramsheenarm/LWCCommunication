declare module "@salesforce/contentAssetUrl/ursusparkapplogo" {
    var ursusparkapplogo: string;
    export default ursusparkapplogo;
}