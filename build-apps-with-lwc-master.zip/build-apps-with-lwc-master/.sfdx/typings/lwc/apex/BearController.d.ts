declare module "@salesforce/apex/BearController.getAllBears" {
  export default function getAllBears(): Promise<any>;
}
declare module "@salesforce/apex/BearController.searchBears" {
  export default function searchBears(param: {searchTerm: any}): Promise<any>;
}
